import { NgModule } from '@angular/core';

import { ApplicationCompleteService } from './application-complete.service';

@NgModule({
  providers: [ ApplicationCompleteService ]
})
export class GeneralCoreModule { }
