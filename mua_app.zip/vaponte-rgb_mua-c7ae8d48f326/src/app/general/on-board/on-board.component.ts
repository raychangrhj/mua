import { Component } from '@angular/core';
import { BaseComponent } from '../../shared/base/base.component';

@Component({
  selector: 'regions-on-board',
  templateUrl: './on-board.component.html',
  styleUrls: ['../../shared/top-level.component.scss', './on-board.component.scss']
})
export class GeneralOnBoardComponent extends BaseComponent { }
