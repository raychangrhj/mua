export interface AppConfig {
  serviceContext: string;
  environment: string;
  loggingEndpoint: string;
  loggingLevel: string;
}
